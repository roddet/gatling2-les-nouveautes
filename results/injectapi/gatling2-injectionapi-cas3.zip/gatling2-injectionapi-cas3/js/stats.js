var stats = {
    type: "GROUP",
contents: {
"recherche-jcertif-4bcdc0a33c140f993ada5e2c195c153c": {
        type: "REQUEST",
        name: "Recherche JCertif",
path: "Recherche JCertif",
pathFormatted: "recherche-jcertif-4bcdc0a33c140f993ada5e2c195c153c",
stats: {
    "name": "Recherche JCertif",
    "numberOfRequests": {
        "total": "50",
        "ok": "50",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "400",
        "ok": "400",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "710",
        "ok": "710",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "471",
        "ok": "471",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "61",
        "ok": "61",
        "ko": "-"
    },
    "percentiles1": {
        "total": "560",
        "ok": "560",
        "ko": "-"
    },
    "percentiles2": {
        "total": "710",
        "ok": "710",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 50,
        "percentage": 100
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    }
}
    },"recherche-gatling-50284d42eb1efb32a821385c8deb1bcd": {
        type: "REQUEST",
        name: "Recherche Gatling",
path: "Recherche Gatling",
pathFormatted: "recherche-gatling-50284d42eb1efb32a821385c8deb1bcd",
stats: {
    "name": "Recherche Gatling",
    "numberOfRequests": {
        "total": "50",
        "ok": "50",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "200",
        "ok": "200",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1210",
        "ok": "1210",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "320",
        "ok": "320",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "170",
        "ok": "170",
        "ko": "-"
    },
    "percentiles1": {
        "total": "570",
        "ok": "570",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1210",
        "ok": "1210",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 48,
        "percentage": 96
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 1,
        "percentage": 2
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 1,
        "percentage": 2
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    }
}
    },"recherche-nantes-eb50deb3276835e6bf0bca74f216aaa0": {
        type: "REQUEST",
        name: "Recherche Nantes",
path: "Recherche Nantes",
pathFormatted: "recherche-nantes-eb50deb3276835e6bf0bca74f216aaa0",
stats: {
    "name": "Recherche Nantes",
    "numberOfRequests": {
        "total": "50",
        "ok": "50",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "210",
        "ok": "210",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1490",
        "ok": "1490",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "375",
        "ok": "375",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "215",
        "ok": "215",
        "ko": "-"
    },
    "percentiles1": {
        "total": "610",
        "ok": "610",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1490",
        "ok": "1490",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 48,
        "percentage": 96
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 1,
        "percentage": 2
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 1,
        "percentage": 2
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    }
}
    },"recherche-scala-d87bdb5515896b5ed9c6a685b3a0f461": {
        type: "REQUEST",
        name: "Recherche Scala",
path: "Recherche Scala",
pathFormatted: "recherche-scala-d87bdb5515896b5ed9c6a685b3a0f461",
stats: {
    "name": "Recherche Scala",
    "numberOfRequests": {
        "total": "50",
        "ok": "50",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "200",
        "ok": "200",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1520",
        "ok": "1520",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "394",
        "ok": "394",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "235",
        "ok": "235",
        "ko": "-"
    },
    "percentiles1": {
        "total": "710",
        "ok": "710",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1520",
        "ok": "1520",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 48,
        "percentage": 96
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 2,
        "percentage": 4
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    }
}
    }
},
name: "Global Information",
path: "",
pathFormatted: "missing-name-b06d1db11321396efb70c5c483b11923",
stats: {
    "name": "Global Information",
    "numberOfRequests": {
        "total": "200",
        "ok": "200",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "200",
        "ok": "200",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1520",
        "ok": "1520",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "390",
        "ok": "390",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "191",
        "ok": "191",
        "ko": "-"
    },
    "percentiles1": {
        "total": "630",
        "ok": "630",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1250",
        "ok": "1250",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 194,
        "percentage": 97
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 2,
        "percentage": 1
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 4,
        "percentage": 2
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "1",
        "ok": "1",
        "ko": "-"
    }
}

}

function fillStats(stat){
    $("#numberOfRequests").append(stat.numberOfRequests.total);
    $("#numberOfRequestsOK").append(stat.numberOfRequests.ok);
    $("#numberOfRequestsKO").append(stat.numberOfRequests.ko);

    $("#minResponseTime").append(stat.minResponseTime.total);
    $("#minResponseTimeOK").append(stat.minResponseTime.ok);
    $("#minResponseTimeKO").append(stat.minResponseTime.ko);

    $("#maxResponseTime").append(stat.maxResponseTime.total);
    $("#maxResponseTimeOK").append(stat.maxResponseTime.ok);
    $("#maxResponseTimeKO").append(stat.maxResponseTime.ko);

    $("#meanResponseTime").append(stat.meanResponseTime.total);
    $("#meanResponseTimeOK").append(stat.meanResponseTime.ok);
    $("#meanResponseTimeKO").append(stat.meanResponseTime.ko);

    $("#standardDeviation").append(stat.standardDeviation.total);
    $("#standardDeviationOK").append(stat.standardDeviation.ok);
    $("#standardDeviationKO").append(stat.standardDeviation.ko);

    $("#percentiles1").append(stat.percentiles1.total);
    $("#percentiles1OK").append(stat.percentiles1.ok);
    $("#percentiles1KO").append(stat.percentiles1.ko);

    $("#percentiles2").append(stat.percentiles2.total);
    $("#percentiles2OK").append(stat.percentiles2.ok);
    $("#percentiles2KO").append(stat.percentiles2.ko);

    $("#meanNumberOfRequestsPerSecond").append(stat.meanNumberOfRequestsPerSecond.total);
    $("#meanNumberOfRequestsPerSecondOK").append(stat.meanNumberOfRequestsPerSecond.ok);
    $("#meanNumberOfRequestsPerSecondKO").append(stat.meanNumberOfRequestsPerSecond.ko);
}
