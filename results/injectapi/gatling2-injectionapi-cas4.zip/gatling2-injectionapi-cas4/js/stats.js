var stats = {
    type: "GROUP",
contents: {
"recherche-jcertif-4bcdc0a33c140f993ada5e2c195c153c": {
        type: "REQUEST",
        name: "Recherche JCertif",
path: "Recherche JCertif",
pathFormatted: "recherche-jcertif-4bcdc0a33c140f993ada5e2c195c153c",
stats: {
    "name": "Recherche JCertif",
    "numberOfRequests": {
        "total": "240",
        "ok": "239",
        "ko": "1"
    },
    "minResponseTime": {
        "total": "390",
        "ok": "390",
        "ko": "410"
    },
    "maxResponseTime": {
        "total": "840",
        "ok": "840",
        "ko": "410"
    },
    "meanResponseTime": {
        "total": "451",
        "ok": "451",
        "ko": "410"
    },
    "standardDeviation": {
        "total": "64",
        "ok": "65",
        "ko": "0"
    },
    "percentiles1": {
        "total": "590",
        "ok": "590",
        "ko": "410"
    },
    "percentiles2": {
        "total": "690",
        "ok": "690",
        "ko": "410"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 238,
        "percentage": 99
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 1,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 1,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "2",
        "ok": "2",
        "ko": "0"
    }
}
    },"recherche-gatling-50284d42eb1efb32a821385c8deb1bcd": {
        type: "REQUEST",
        name: "Recherche Gatling",
path: "Recherche Gatling",
pathFormatted: "recherche-gatling-50284d42eb1efb32a821385c8deb1bcd",
stats: {
    "name": "Recherche Gatling",
    "numberOfRequests": {
        "total": "240",
        "ok": "240",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "200",
        "ok": "200",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1620",
        "ok": "1620",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "292",
        "ok": "292",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "147",
        "ok": "147",
        "ko": "-"
    },
    "percentiles1": {
        "total": "450",
        "ok": "450",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1040",
        "ok": "1040",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 236,
        "percentage": 98
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 2,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 2,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "2",
        "ok": "2",
        "ko": "-"
    }
}
    },"recherche-nantes-eb50deb3276835e6bf0bca74f216aaa0": {
        type: "REQUEST",
        name: "Recherche Nantes",
path: "Recherche Nantes",
pathFormatted: "recherche-nantes-eb50deb3276835e6bf0bca74f216aaa0",
stats: {
    "name": "Recherche Nantes",
    "numberOfRequests": {
        "total": "240",
        "ok": "240",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "200",
        "ok": "200",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1480",
        "ok": "1480",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "313",
        "ok": "313",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "151",
        "ok": "151",
        "ko": "-"
    },
    "percentiles1": {
        "total": "530",
        "ok": "530",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1160",
        "ok": "1160",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 236,
        "percentage": 98
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 2,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 2,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "2",
        "ok": "2",
        "ko": "-"
    }
}
    },"recherche-scala-d87bdb5515896b5ed9c6a685b3a0f461": {
        type: "REQUEST",
        name: "Recherche Scala",
path: "Recherche Scala",
pathFormatted: "recherche-scala-d87bdb5515896b5ed9c6a685b3a0f461",
stats: {
    "name": "Recherche Scala",
    "numberOfRequests": {
        "total": "240",
        "ok": "240",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "200",
        "ok": "200",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1620",
        "ok": "1620",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "333",
        "ok": "333",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "190",
        "ok": "190",
        "ko": "-"
    },
    "percentiles1": {
        "total": "530",
        "ok": "530",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1260",
        "ok": "1260",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 233,
        "percentage": 97
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 3,
        "percentage": 1
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 4,
        "percentage": 1
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "2",
        "ok": "2",
        "ko": "-"
    }
}
    }
},
name: "Global Information",
path: "",
pathFormatted: "missing-name-b06d1db11321396efb70c5c483b11923",
stats: {
    "name": "Global Information",
    "numberOfRequests": {
        "total": "960",
        "ok": "959",
        "ko": "1"
    },
    "minResponseTime": {
        "total": "200",
        "ok": "200",
        "ko": "410"
    },
    "maxResponseTime": {
        "total": "1620",
        "ok": "1620",
        "ko": "410"
    },
    "meanResponseTime": {
        "total": "347",
        "ok": "347",
        "ko": "410"
    },
    "standardDeviation": {
        "total": "158",
        "ok": "158",
        "ko": "0"
    },
    "percentiles1": {
        "total": "540",
        "ok": "540",
        "ko": "410"
    },
    "percentiles2": {
        "total": "1090",
        "ok": "1090",
        "ko": "410"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 943,
        "percentage": 98
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 8,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 8,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 1,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "8",
        "ok": "8",
        "ko": "0"
    }
}

}

function fillStats(stat){
    $("#numberOfRequests").append(stat.numberOfRequests.total);
    $("#numberOfRequestsOK").append(stat.numberOfRequests.ok);
    $("#numberOfRequestsKO").append(stat.numberOfRequests.ko);

    $("#minResponseTime").append(stat.minResponseTime.total);
    $("#minResponseTimeOK").append(stat.minResponseTime.ok);
    $("#minResponseTimeKO").append(stat.minResponseTime.ko);

    $("#maxResponseTime").append(stat.maxResponseTime.total);
    $("#maxResponseTimeOK").append(stat.maxResponseTime.ok);
    $("#maxResponseTimeKO").append(stat.maxResponseTime.ko);

    $("#meanResponseTime").append(stat.meanResponseTime.total);
    $("#meanResponseTimeOK").append(stat.meanResponseTime.ok);
    $("#meanResponseTimeKO").append(stat.meanResponseTime.ko);

    $("#standardDeviation").append(stat.standardDeviation.total);
    $("#standardDeviationOK").append(stat.standardDeviation.ok);
    $("#standardDeviationKO").append(stat.standardDeviation.ko);

    $("#percentiles1").append(stat.percentiles1.total);
    $("#percentiles1OK").append(stat.percentiles1.ok);
    $("#percentiles1KO").append(stat.percentiles1.ko);

    $("#percentiles2").append(stat.percentiles2.total);
    $("#percentiles2OK").append(stat.percentiles2.ok);
    $("#percentiles2KO").append(stat.percentiles2.ko);

    $("#meanNumberOfRequestsPerSecond").append(stat.meanNumberOfRequestsPerSecond.total);
    $("#meanNumberOfRequestsPerSecondOK").append(stat.meanNumberOfRequestsPerSecond.ok);
    $("#meanNumberOfRequestsPerSecondKO").append(stat.meanNumberOfRequestsPerSecond.ko);
}
