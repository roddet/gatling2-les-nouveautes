var stats = {
    type: "GROUP",
contents: {
"recherche-jcertif-4bcdc0a33c140f993ada5e2c195c153c": {
        type: "REQUEST",
        name: "Recherche JCertif",
path: "Recherche JCertif",
pathFormatted: "recherche-jcertif-4bcdc0a33c140f993ada5e2c195c153c",
stats: {
    "name": "Recherche JCertif",
    "numberOfRequests": {
        "total": "100",
        "ok": "100",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "390",
        "ok": "390",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "930",
        "ok": "930",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "498",
        "ok": "498",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "90",
        "ok": "90",
        "ko": "-"
    },
    "percentiles1": {
        "total": "680",
        "ok": "680",
        "ko": "-"
    },
    "percentiles2": {
        "total": "800",
        "ok": "800",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 98,
        "percentage": 98
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 2,
        "percentage": 2
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    }
}
    },"recherche-gatling-50284d42eb1efb32a821385c8deb1bcd": {
        type: "REQUEST",
        name: "Recherche Gatling",
path: "Recherche Gatling",
pathFormatted: "recherche-gatling-50284d42eb1efb32a821385c8deb1bcd",
stats: {
    "name": "Recherche Gatling",
    "numberOfRequests": {
        "total": "100",
        "ok": "100",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "210",
        "ok": "210",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1330",
        "ok": "1330",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "350",
        "ok": "350",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "190",
        "ok": "190",
        "ko": "-"
    },
    "percentiles1": {
        "total": "790",
        "ok": "790",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1050",
        "ok": "1050",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 95,
        "percentage": 95
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 4,
        "percentage": 4
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 1,
        "percentage": 1
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    }
}
    },"recherche-nantes-eb50deb3276835e6bf0bca74f216aaa0": {
        type: "REQUEST",
        name: "Recherche Nantes",
path: "Recherche Nantes",
pathFormatted: "recherche-nantes-eb50deb3276835e6bf0bca74f216aaa0",
stats: {
    "name": "Recherche Nantes",
    "numberOfRequests": {
        "total": "100",
        "ok": "100",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "210",
        "ok": "210",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1180",
        "ok": "1180",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "371",
        "ok": "371",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "187",
        "ok": "187",
        "ko": "-"
    },
    "percentiles1": {
        "total": "630",
        "ok": "630",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1170",
        "ok": "1170",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 95,
        "percentage": 95
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 5,
        "percentage": 5
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    }
}
    },"recherche-scala-d87bdb5515896b5ed9c6a685b3a0f461": {
        type: "REQUEST",
        name: "Recherche Scala",
path: "Recherche Scala",
pathFormatted: "recherche-scala-d87bdb5515896b5ed9c6a685b3a0f461",
stats: {
    "name": "Recherche Scala",
    "numberOfRequests": {
        "total": "100",
        "ok": "100",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "210",
        "ok": "210",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1140",
        "ok": "1140",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "376",
        "ok": "376",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "184",
        "ok": "184",
        "ko": "-"
    },
    "percentiles1": {
        "total": "640",
        "ok": "640",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1100",
        "ok": "1100",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 95,
        "percentage": 95
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 5,
        "percentage": 5
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    }
}
    }
},
name: "Global Information",
path: "",
pathFormatted: "missing-name-b06d1db11321396efb70c5c483b11923",
stats: {
    "name": "Global Information",
    "numberOfRequests": {
        "total": "400",
        "ok": "400",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "210",
        "ok": "210",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1330",
        "ok": "1330",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "399",
        "ok": "399",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "177",
        "ok": "177",
        "ko": "-"
    },
    "percentiles1": {
        "total": "730",
        "ok": "730",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1100",
        "ok": "1100",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 383,
        "percentage": 95
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 16,
        "percentage": 4
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 1,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "1",
        "ok": "1",
        "ko": "-"
    }
}

}

function fillStats(stat){
    $("#numberOfRequests").append(stat.numberOfRequests.total);
    $("#numberOfRequestsOK").append(stat.numberOfRequests.ok);
    $("#numberOfRequestsKO").append(stat.numberOfRequests.ko);

    $("#minResponseTime").append(stat.minResponseTime.total);
    $("#minResponseTimeOK").append(stat.minResponseTime.ok);
    $("#minResponseTimeKO").append(stat.minResponseTime.ko);

    $("#maxResponseTime").append(stat.maxResponseTime.total);
    $("#maxResponseTimeOK").append(stat.maxResponseTime.ok);
    $("#maxResponseTimeKO").append(stat.maxResponseTime.ko);

    $("#meanResponseTime").append(stat.meanResponseTime.total);
    $("#meanResponseTimeOK").append(stat.meanResponseTime.ok);
    $("#meanResponseTimeKO").append(stat.meanResponseTime.ko);

    $("#standardDeviation").append(stat.standardDeviation.total);
    $("#standardDeviationOK").append(stat.standardDeviation.ok);
    $("#standardDeviationKO").append(stat.standardDeviation.ko);

    $("#percentiles1").append(stat.percentiles1.total);
    $("#percentiles1OK").append(stat.percentiles1.ok);
    $("#percentiles1KO").append(stat.percentiles1.ko);

    $("#percentiles2").append(stat.percentiles2.total);
    $("#percentiles2OK").append(stat.percentiles2.ok);
    $("#percentiles2KO").append(stat.percentiles2.ko);

    $("#meanNumberOfRequestsPerSecond").append(stat.meanNumberOfRequestsPerSecond.total);
    $("#meanNumberOfRequestsPerSecondOK").append(stat.meanNumberOfRequestsPerSecond.ok);
    $("#meanNumberOfRequestsPerSecondKO").append(stat.meanNumberOfRequestsPerSecond.ko);
}
