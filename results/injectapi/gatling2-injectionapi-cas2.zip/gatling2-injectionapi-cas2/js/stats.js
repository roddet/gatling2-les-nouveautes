var stats = {
    type: "GROUP",
contents: {
"recherche-jcertif-4bcdc0a33c140f993ada5e2c195c153c": {
        type: "REQUEST",
        name: "Recherche JCertif",
path: "Recherche JCertif",
pathFormatted: "recherche-jcertif-4bcdc0a33c140f993ada5e2c195c153c",
stats: {
    "name": "Recherche JCertif",
    "numberOfRequests": {
        "total": "150",
        "ok": "150",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "390",
        "ok": "390",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "2880",
        "ok": "2880",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1006",
        "ok": "1006",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "478",
        "ok": "478",
        "ko": "-"
    },
    "percentiles1": {
        "total": "1510",
        "ok": "1510",
        "ko": "-"
    },
    "percentiles2": {
        "total": "2730",
        "ok": "2730",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 63,
        "percentage": 42
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 21,
        "percentage": 14
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 66,
        "percentage": 44
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "11",
        "ok": "11",
        "ko": "-"
    }
}
    },"recherche-gatling-50284d42eb1efb32a821385c8deb1bcd": {
        type: "REQUEST",
        name: "Recherche Gatling",
path: "Recherche Gatling",
pathFormatted: "recherche-gatling-50284d42eb1efb32a821385c8deb1bcd",
stats: {
    "name": "Recherche Gatling",
    "numberOfRequests": {
        "total": "150",
        "ok": "150",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "210",
        "ok": "210",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "3450",
        "ok": "3450",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "866",
        "ok": "866",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "528",
        "ok": "528",
        "ko": "-"
    },
    "percentiles1": {
        "total": "1570",
        "ok": "1570",
        "ko": "-"
    },
    "percentiles2": {
        "total": "2340",
        "ok": "2340",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 62,
        "percentage": 41
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 50,
        "percentage": 33
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 38,
        "percentage": 25
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "11",
        "ok": "11",
        "ko": "-"
    }
}
    },"recherche-nantes-eb50deb3276835e6bf0bca74f216aaa0": {
        type: "REQUEST",
        name: "Recherche Nantes",
path: "Recherche Nantes",
pathFormatted: "recherche-nantes-eb50deb3276835e6bf0bca74f216aaa0",
stats: {
    "name": "Recherche Nantes",
    "numberOfRequests": {
        "total": "150",
        "ok": "150",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "210",
        "ok": "210",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "3400",
        "ok": "3400",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "659",
        "ok": "659",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "469",
        "ok": "469",
        "ko": "-"
    },
    "percentiles1": {
        "total": "1300",
        "ok": "1300",
        "ko": "-"
    },
    "percentiles2": {
        "total": "2390",
        "ok": "2390",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 99,
        "percentage": 66
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 38,
        "percentage": 25
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 13,
        "percentage": 8
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "11",
        "ok": "11",
        "ko": "-"
    }
}
    },"recherche-scala-d87bdb5515896b5ed9c6a685b3a0f461": {
        type: "REQUEST",
        name: "Recherche Scala",
path: "Recherche Scala",
pathFormatted: "recherche-scala-d87bdb5515896b5ed9c6a685b3a0f461",
stats: {
    "name": "Recherche Scala",
    "numberOfRequests": {
        "total": "150",
        "ok": "150",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "200",
        "ok": "200",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "2200",
        "ok": "2200",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "514",
        "ok": "514",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "351",
        "ok": "351",
        "ko": "-"
    },
    "percentiles1": {
        "total": "1140",
        "ok": "1140",
        "ko": "-"
    },
    "percentiles2": {
        "total": "2180",
        "ok": "2180",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 130,
        "percentage": 86
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 14,
        "percentage": 9
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 6,
        "percentage": 4
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "11",
        "ok": "11",
        "ko": "-"
    }
}
    }
},
name: "Global Information",
path: "",
pathFormatted: "missing-name-b06d1db11321396efb70c5c483b11923",
stats: {
    "name": "Global Information",
    "numberOfRequests": {
        "total": "600",
        "ok": "600",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "200",
        "ok": "200",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "3450",
        "ok": "3450",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "761",
        "ok": "761",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "499",
        "ok": "499",
        "ko": "-"
    },
    "percentiles1": {
        "total": "1510",
        "ok": "1510",
        "ko": "-"
    },
    "percentiles2": {
        "total": "2340",
        "ok": "2340",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 354,
        "percentage": 59
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 123,
        "percentage": 20
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 123,
        "percentage": 20
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "44",
        "ok": "44",
        "ko": "-"
    }
}

}

function fillStats(stat){
    $("#numberOfRequests").append(stat.numberOfRequests.total);
    $("#numberOfRequestsOK").append(stat.numberOfRequests.ok);
    $("#numberOfRequestsKO").append(stat.numberOfRequests.ko);

    $("#minResponseTime").append(stat.minResponseTime.total);
    $("#minResponseTimeOK").append(stat.minResponseTime.ok);
    $("#minResponseTimeKO").append(stat.minResponseTime.ko);

    $("#maxResponseTime").append(stat.maxResponseTime.total);
    $("#maxResponseTimeOK").append(stat.maxResponseTime.ok);
    $("#maxResponseTimeKO").append(stat.maxResponseTime.ko);

    $("#meanResponseTime").append(stat.meanResponseTime.total);
    $("#meanResponseTimeOK").append(stat.meanResponseTime.ok);
    $("#meanResponseTimeKO").append(stat.meanResponseTime.ko);

    $("#standardDeviation").append(stat.standardDeviation.total);
    $("#standardDeviationOK").append(stat.standardDeviation.ok);
    $("#standardDeviationKO").append(stat.standardDeviation.ko);

    $("#percentiles1").append(stat.percentiles1.total);
    $("#percentiles1OK").append(stat.percentiles1.ok);
    $("#percentiles1KO").append(stat.percentiles1.ko);

    $("#percentiles2").append(stat.percentiles2.total);
    $("#percentiles2OK").append(stat.percentiles2.ok);
    $("#percentiles2KO").append(stat.percentiles2.ko);

    $("#meanNumberOfRequestsPerSecond").append(stat.meanNumberOfRequestsPerSecond.total);
    $("#meanNumberOfRequestsPerSecondOK").append(stat.meanNumberOfRequestsPerSecond.ok);
    $("#meanNumberOfRequestsPerSecondKO").append(stat.meanNumberOfRequestsPerSecond.ko);
}
