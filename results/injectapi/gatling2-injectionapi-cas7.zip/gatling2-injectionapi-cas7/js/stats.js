var stats = {
    type: "GROUP",
contents: {
"recherche-twitter-jcertif-8a33647f9dcd31997a9c00fe4e1fe711": {
        type: "REQUEST",
        name: "Recherche Twitter JCertif",
path: "Recherche Twitter JCertif",
pathFormatted: "recherche-twitter-jcertif-8a33647f9dcd31997a9c00fe4e1fe711",
stats: {
    "name": "Recherche Twitter JCertif",
    "numberOfRequests": {
        "total": "40",
        "ok": "40",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "450",
        "ok": "450",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "4220",
        "ok": "4220",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1503",
        "ok": "1503",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "1281",
        "ok": "1281",
        "ko": "-"
    },
    "percentiles1": {
        "total": "4170",
        "ok": "4170",
        "ko": "-"
    },
    "percentiles2": {
        "total": "4220",
        "ok": "4220",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 20,
        "percentage": 50
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 6,
        "percentage": 15
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 14,
        "percentage": 35
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "3",
        "ok": "3",
        "ko": "-"
    }
}
    },"recherche-facebook-jcertif-582671898340b5eae1e45b33a3af8c7b": {
        type: "REQUEST",
        name: "Recherche Facebook JCertif",
path: "Recherche Facebook JCertif",
pathFormatted: "recherche-facebook-jcertif-582671898340b5eae1e45b33a3af8c7b",
stats: {
    "name": "Recherche Facebook JCertif",
    "numberOfRequests": {
        "total": "40",
        "ok": "40",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1240",
        "ok": "1240",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "4050",
        "ok": "4050",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "2287",
        "ok": "2287",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "676",
        "ok": "676",
        "ko": "-"
    },
    "percentiles1": {
        "total": "3680",
        "ok": "3680",
        "ko": "-"
    },
    "percentiles2": {
        "total": "4050",
        "ok": "4050",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 0,
        "percentage": 0
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 40,
        "percentage": 100
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "3",
        "ok": "3",
        "ko": "-"
    }
}
    },"recherche-twitter-gatling-ded8329da8bb5fc719eae2a85f2f2564": {
        type: "REQUEST",
        name: "Recherche Twitter Gatling",
path: "Recherche Twitter Gatling",
pathFormatted: "recherche-twitter-gatling-ded8329da8bb5fc719eae2a85f2f2564",
stats: {
    "name": "Recherche Twitter Gatling",
    "numberOfRequests": {
        "total": "40",
        "ok": "40",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "390",
        "ok": "390",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "2160",
        "ok": "2160",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "686",
        "ok": "686",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "343",
        "ok": "343",
        "ko": "-"
    },
    "percentiles1": {
        "total": "1180",
        "ok": "1180",
        "ko": "-"
    },
    "percentiles2": {
        "total": "2160",
        "ok": "2160",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 32,
        "percentage": 80
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 6,
        "percentage": 15
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 2,
        "percentage": 5
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "3",
        "ok": "3",
        "ko": "-"
    }
}
    },"recherche-twitter-nantes-1d27f35c31021d0de8b9274fa09ac5c7": {
        type: "REQUEST",
        name: "Recherche Twitter Nantes",
path: "Recherche Twitter Nantes",
pathFormatted: "recherche-twitter-nantes-1d27f35c31021d0de8b9274fa09ac5c7",
stats: {
    "name": "Recherche Twitter Nantes",
    "numberOfRequests": {
        "total": "40",
        "ok": "40",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "400",
        "ok": "400",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "2790",
        "ok": "2790",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1115",
        "ok": "1115",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "662",
        "ok": "662",
        "ko": "-"
    },
    "percentiles1": {
        "total": "2490",
        "ok": "2490",
        "ko": "-"
    },
    "percentiles2": {
        "total": "2790",
        "ok": "2790",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 19,
        "percentage": 47
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 9,
        "percentage": 22
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 12,
        "percentage": 30
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "3",
        "ok": "3",
        "ko": "-"
    }
}
    },"recherche-facebook-gatling-d5fd4e99446deaab2acbd26837aa6615": {
        type: "REQUEST",
        name: "Recherche Facebook Gatling",
path: "Recherche Facebook Gatling",
pathFormatted: "recherche-facebook-gatling-d5fd4e99446deaab2acbd26837aa6615",
stats: {
    "name": "Recherche Facebook Gatling",
    "numberOfRequests": {
        "total": "40",
        "ok": "40",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1490",
        "ok": "1490",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "3680",
        "ok": "3680",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "2033",
        "ok": "2033",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "430",
        "ok": "430",
        "ko": "-"
    },
    "percentiles1": {
        "total": "2670",
        "ok": "2670",
        "ko": "-"
    },
    "percentiles2": {
        "total": "3680",
        "ok": "3680",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 0,
        "percentage": 0
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 40,
        "percentage": 100
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "3",
        "ok": "3",
        "ko": "-"
    }
}
    },"recherche-twitter-scala-da402a07b1634c07adc52ea3483bfbbd": {
        type: "REQUEST",
        name: "Recherche Twitter Scala",
path: "Recherche Twitter Scala",
pathFormatted: "recherche-twitter-scala-da402a07b1634c07adc52ea3483bfbbd",
stats: {
    "name": "Recherche Twitter Scala",
    "numberOfRequests": {
        "total": "40",
        "ok": "40",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "370",
        "ok": "370",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "3750",
        "ok": "3750",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1082",
        "ok": "1082",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "642",
        "ok": "642",
        "ko": "-"
    },
    "percentiles1": {
        "total": "2350",
        "ok": "2350",
        "ko": "-"
    },
    "percentiles2": {
        "total": "3750",
        "ok": "3750",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 15,
        "percentage": 37
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 14,
        "percentage": 35
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 11,
        "percentage": 27
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "3",
        "ok": "3",
        "ko": "-"
    }
}
    },"recherche-facebook-nantes-0c671c0513a749068448a80c8166d618": {
        type: "REQUEST",
        name: "Recherche Facebook Nantes",
path: "Recherche Facebook Nantes",
pathFormatted: "recherche-facebook-nantes-0c671c0513a749068448a80c8166d618",
stats: {
    "name": "Recherche Facebook Nantes",
    "numberOfRequests": {
        "total": "40",
        "ok": "40",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1790",
        "ok": "1790",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "6900",
        "ok": "6900",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "2211",
        "ok": "2211",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "819",
        "ok": "819",
        "ko": "-"
    },
    "percentiles1": {
        "total": "3310",
        "ok": "3310",
        "ko": "-"
    },
    "percentiles2": {
        "total": "6900",
        "ok": "6900",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 0,
        "percentage": 0
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 40,
        "percentage": 100
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "3",
        "ok": "3",
        "ko": "-"
    }
}
    },"recherche-facebook-scala-b0a2bdea4ba318919fda6c1c3c9bba41": {
        type: "REQUEST",
        name: "Recherche Facebook Scala",
path: "Recherche Facebook Scala",
pathFormatted: "recherche-facebook-scala-b0a2bdea4ba318919fda6c1c3c9bba41",
stats: {
    "name": "Recherche Facebook Scala",
    "numberOfRequests": {
        "total": "40",
        "ok": "40",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1770",
        "ok": "1770",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "2240",
        "ok": "2240",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1999",
        "ok": "1999",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "123",
        "ok": "123",
        "ko": "-"
    },
    "percentiles1": {
        "total": "2200",
        "ok": "2200",
        "ko": "-"
    },
    "percentiles2": {
        "total": "2240",
        "ok": "2240",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 0,
        "percentage": 0
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 40,
        "percentage": 100
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "3",
        "ok": "3",
        "ko": "-"
    }
}
    }
},
name: "Global Information",
path: "",
pathFormatted: "missing-name-b06d1db11321396efb70c5c483b11923",
stats: {
    "name": "Global Information",
    "numberOfRequests": {
        "total": "320",
        "ok": "320",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "370",
        "ok": "370",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "6900",
        "ok": "6900",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1614",
        "ok": "1614",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "901",
        "ok": "901",
        "ko": "-"
    },
    "percentiles1": {
        "total": "3160",
        "ok": "3160",
        "ko": "-"
    },
    "percentiles2": {
        "total": "4170",
        "ok": "4170",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 86,
        "percentage": 26
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 35,
        "percentage": 10
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 199,
        "percentage": 62
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "25",
        "ok": "25",
        "ko": "-"
    }
}

}

function fillStats(stat){
    $("#numberOfRequests").append(stat.numberOfRequests.total);
    $("#numberOfRequestsOK").append(stat.numberOfRequests.ok);
    $("#numberOfRequestsKO").append(stat.numberOfRequests.ko);

    $("#minResponseTime").append(stat.minResponseTime.total);
    $("#minResponseTimeOK").append(stat.minResponseTime.ok);
    $("#minResponseTimeKO").append(stat.minResponseTime.ko);

    $("#maxResponseTime").append(stat.maxResponseTime.total);
    $("#maxResponseTimeOK").append(stat.maxResponseTime.ok);
    $("#maxResponseTimeKO").append(stat.maxResponseTime.ko);

    $("#meanResponseTime").append(stat.meanResponseTime.total);
    $("#meanResponseTimeOK").append(stat.meanResponseTime.ok);
    $("#meanResponseTimeKO").append(stat.meanResponseTime.ko);

    $("#standardDeviation").append(stat.standardDeviation.total);
    $("#standardDeviationOK").append(stat.standardDeviation.ok);
    $("#standardDeviationKO").append(stat.standardDeviation.ko);

    $("#percentiles1").append(stat.percentiles1.total);
    $("#percentiles1OK").append(stat.percentiles1.ok);
    $("#percentiles1KO").append(stat.percentiles1.ko);

    $("#percentiles2").append(stat.percentiles2.total);
    $("#percentiles2OK").append(stat.percentiles2.ok);
    $("#percentiles2KO").append(stat.percentiles2.ko);

    $("#meanNumberOfRequestsPerSecond").append(stat.meanNumberOfRequestsPerSecond.total);
    $("#meanNumberOfRequestsPerSecondOK").append(stat.meanNumberOfRequestsPerSecond.ok);
    $("#meanNumberOfRequestsPerSecondKO").append(stat.meanNumberOfRequestsPerSecond.ko);
}
